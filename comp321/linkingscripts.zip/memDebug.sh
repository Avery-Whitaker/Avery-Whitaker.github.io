#!/bin/bash

#this command magicly finds all your illegal memory usages
#also finds all your data leaks

#pass command to run as parameter

valgrind --vgdb-error=1 --leak-check=yes --tool=memcheck --num-callers=16 --leak-resolution=high "$1"