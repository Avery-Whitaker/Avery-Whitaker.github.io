#!/bin/bash
#Author: Avery Whitaker
#Name of file as parameter
if [ "$#" -ne 1 ]; then
    echo "Illegal number of parameters"
else
  clang-format "-style={BasedOnStyle: LLVM,ColumnLimit: 79,UseTab: Never,Language: Cpp,AlignConsecutiveAssignments: false,AlwaysBreakAfterDefinitionReturnType: All,IndentWidth: 4,SpaceBeforeParens: ControlStatements,TabWidth: 4,BreakBeforeBraces: Linux,AllowShortIfStatementsOnASingleLine: false,IndentCaseLabels: true }" -i $1
fi
