#!/bin/bash
#Author: Avery Whitaker
#Script built for testing comp321 projects
#Specilized version of my generic autograder

#set -x

executable="./readjcf -de"
testFileDir="grade_data/test_files/"
referenceSolution="./grade_data/reference -de"

if ! (make > /dev/null) ; then
	exit 1
fi

function compare {
	if diff -q "$1" "$2" > /dev/null ; then
			return 0
		else		
			printf "Does not match expected output\n"
			printf "\n\n - Diff: - \n"
			diff $1 $2
			printf "\n\n - Your output: - \n"
		    cat "$1"
		    printf "\n\n - Expected Output: - \n"
		    cat "$2"
			printf "\n"
			return 1
	fi
}

#run inputfile outputfile
function run {
	timeGiven=10 # 10 seconds
	memGiven=1000000 # 1 MegaByte
	output="grade_data/temp/output"
	runerr="grade_data/temp/runtime.err"

	perl grade_data/timeout.pl -t "$timeGiven" -m $memGiven -x 1 --confess --detect-hangups ${executable} "$1" 1> "$output" 2> "$runerr"

	execrtrn=$?

	cat "$runerr" | grep "^MEM" > /dev/null
		if [[ $? == 0 ]]; then
			printf " - Program Used Too Much Memory - \n"
			return 1
	fi

	cat "$runerr" | grep "^TIMEOUT" > /dev/null
		if [[ $? == 0 ]]; then
			printf " - Time Limit Is Exhausted - \n"
			return 1
	fi

	cat "$runerr" | grep "^HANGUP" > /dev/null
		if [[ $? == 0 ]]; then
			printf " - Program Hanged - \n"
			return 1
	fi

	cat "$runerr" | grep "^SIGNAL" > /dev/null
		if [[ $? == 0 ]]; then
			printf " - Program Was Termined By Signal - \n"
			return 1
	fi

	if (( $execrtrn >= "128" )) ; then
		printf " -- Program Returned Error Code -- \n"
		printf " - SysOut - \n"
		cat "$output"
		printf " - SysErr - \n"
		cat "$runerr"
		return 1
	elif [ $execrtrn == "1" ] ; then
		echo " -- Runtime Error -- "
		printf " - SysOut - \n"
		cat "$output"
		printf " - SysErr - \n"
		cat "$runerr"
		return 1
	elif [ $execrtrn == "0" ] ; then
		compare "$output" "$2"
		return $?
	else
		printf " -- Unknown Error  -- "
		printf "output code: "
		printf $execrtrn
		printf "\n"
		printf " - SysOut - \n"
		cat "$output"
		printf " - SysErr - \n"
		cat "$runerr"
		return 1
	fi
}

mkdir grade_data/solutions 2> /dev/null
mkdir grade_data/temp 2> /dev/null

flag=true
i=0
count=0
for filename in ${testFileDir}* 
do
	((count++))
done
time_trigger=$SECONDS+5

for filename in ${testFileDir}* 
do
	((i++))
    correctOutput="grade_data/solutions/$(basename "$filename")_solution"
	${referenceSolution} ${filename} > ${correctOutput}
	run "${filename}" ${correctOutput} > "grade_data/temp/grade.out"
	rtr=$?
	one=1
	if [ $rtr -eq $one ] ; then
		time_trigger=$SECONDS+5
		echo " ----------------     Test ${i}      $(basename $filename)    ---------------- "
		cat "grade_data/temp/grade.out"
		flag=false
	fi;
	if (( $SECONDS > $time_trigger )) ; then
		echo "On run $i of $count ..."
		time_trigger=$SECONDS+5
	fi

	rm core.* 2> /dev/null
done

rm core.* 2> /dev/null
rm *.o 2> /dev/null
rm -R grade_data/solutions 2> /dev/null
rm -R grade_data/temp 2> /dev/null

if $flag ; then
	echo "All $i tests passed. :)"
	exit 0
fi

exit 1